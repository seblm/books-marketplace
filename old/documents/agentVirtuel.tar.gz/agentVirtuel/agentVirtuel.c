#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>

#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <fcntl.h>

/** Demande � l'utilisateur si il veut lire. */
int lire(void) {
  int reponse = -1;
  while (reponse != 0 && reponse != 1) {
    printf("\n - Sens de la communication :\n");
    printf("   0. envoyer\n");
    printf("   1. recevoir\n");
    printf("> ");
    scanf("%d", &reponse);
  }
  return reponse;
}

int menu(char * buffer, char * rep) {
  int reponse = -1, compteur = 1, tailleRepertoire = 0;
  struct dirent * entree;
  DIR * repertoire;
  FILE * fichier;
  char pathname[255];

  repertoire = opendir(rep);

  do {
    compteur = 1;
    printf("\n - Type de message :\n");
    printf("   0. d�connecter (d�connexion physique)\n");

    // Parcours des fichiers
    while ((entree = readdir(repertoire)) != NULL) {
      if (strcmp(entree->d_name, ".") && strcmp(entree->d_name, "..")) {
	printf("   %d. <%s>\n", compteur, entree->d_name);
	compteur++;
      }
    }
    tailleRepertoire = compteur - 1;

    printf("> ");
    scanf("%d", &reponse);
    rewinddir(repertoire);
  } while (reponse < 0 || reponse > tailleRepertoire);

  if (reponse == 0)
    return 0;

  compteur = 0;
  while (compteur < reponse && ((entree = readdir(repertoire)) != NULL))
    if (strcmp(entree->d_name, ".") && strcmp(entree->d_name, ".."))
      compteur++;
  rewinddir(repertoire);

  printf("debug: le message choisi est %s\n", entree->d_name);

  strcpy(pathname, rep);
  strcat(pathname, "/");
  strcat(pathname, entree->d_name);

  if ((fichier = fopen(pathname, "r")) == NULL)
    fprintf(stderr, "Impossible d'ouvrir %d.", pathname);
  else {
    memset(buffer, '\0', 1024);
    char buffer2[4048];
    fread(buffer2, sizeof(char), 4048, fichier);
    strcat(buffer, buffer2);
  }

  close(fichier);
  closedir(repertoire);

  return 1;
}

void protocole(int to_server_socket, char * rep) {
  char buffer[1024] = "";
  int quitter = 0;

  while (!quitter) {
    memset(buffer, '\0', 1024);
    if (lire()) {
      read(to_server_socket, buffer, 1024);
      printf(buffer);
    } else if (menu(buffer, rep))
	write(to_server_socket, buffer, strlen(buffer));
      else
	quitter = 1;
  }
}

int run(char * hote, int port, char * rep) {
  int to_server_socket = -1;
  struct sockaddr_in serverSockAddr;
  struct hostent *serverHostEnt;
  long hostAddr;
  long status;
  
  bzero(&serverSockAddr, sizeof(serverSockAddr)); // Remplit la structure de z�ros
  hostAddr = inet_addr(hote);
  if ((long)hostAddr != (long)-1)
    bcopy(&hostAddr, &serverSockAddr.sin_addr, sizeof(hostAddr));
  else {
    serverHostEnt = gethostbyname(hote);
    if (serverHostEnt == NULL) {
      fprintf(stderr, "Impossible d'obtenir le nom d'h�te sp�cifi�.\n");
      exit(EXIT_FAILURE);
    }
    bcopy(serverHostEnt->h_addr, &serverSockAddr.sin_addr, serverHostEnt->h_length);
  }
  serverSockAddr.sin_port = htons(port);
  serverSockAddr.sin_family = AF_INET;
  
  /* creation de la socket */
  if ((to_server_socket = socket(AF_INET,SOCK_STREAM,0)) < 0) {
    fprintf(stderr, "Impossible de cr�er la socket client.\n");
    exit(EXIT_FAILURE);
  }
  
  /* requete de connexion */
  if(connect(to_server_socket, (struct sockaddr *)&serverSockAddr, sizeof(serverSockAddr)) < 0 ) {
    fprintf(stderr, "Impossible de se connecter.\n");
    exit(EXIT_FAILURE);
  }
  
  protocole(to_server_socket, rep);
  
  /* fermeture de la connection */
  shutdown(to_server_socket,2);
  close(to_server_socket);
  return EXIT_SUCCESS;
}

int main (int argc, char* argv[]) {
  if (argc != 4) {
    fprintf(stderr, "Le nombre d'arguments est incorrect.\nUsage : agentVirtuel <h�te> <port> <r�pertoireFichiersXml>\n");
    return EXIT_FAILURE;
  } else {
    char * hote = argv[1], * rep = argv[3];
    int port = atoi(argv[2]);
    if (opendir(rep) == NULL) {
      fprintf(stderr, "Impossible d'ouvrir Le r�pertoire o� %s doit trouver les fichiers xml.\n", argv[0]);
      return EXIT_FAILURE;
    } else
      return run(hote, port, rep);
  }
}
